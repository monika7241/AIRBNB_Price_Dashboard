CREATE DATABASE Neural_Nebula_040;
USE Neural_Nebula_040;
SELECT * FROM combined_df;



